package foodhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodHubApplicationTests {
/*
	@Test
	void contextLoads() {
	}
*/
}
